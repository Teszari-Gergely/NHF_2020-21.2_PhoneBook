package Phonebook;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
class UMBX0L_NHF_Test {
	public static ArrayList<Entry> phonebook = new ArrayList<Entry>();
	Entry en = new Entry("asd", "asd", "asd", "asd", "asd", "asd");
	Entry en2 = new Entry("qwe", "qwe", "qwe", "qwe", "qwe", "qwe");
	Entry en3 = new Entry("yxc", "yxc", "yxc", "yxc", "yxc", "yxc");
	@Test //1
	void testInsert() {
		assertTrue(DataManipulation.addNew(phonebook, en));
		assertTrue(DataManipulation.addNew(phonebook, en2));
		assertFalse(DataManipulation.addNew(phonebook, en));
	}
	@Test //2
	void testRemove() {
		assertTrue(DataManipulation.removeEntry(phonebook, en.getpNum()));
		assertFalse(DataManipulation.removeEntry(phonebook, en.getpNum()));
	}
	@Test //3
	void testSearch() {
		assertFalse(DataManipulation.searchEntry(phonebook, "1", en2.getlName()).isEmpty());
		assertFalse(DataManipulation.searchEntry(phonebook, "2", en2.getwNum()).isEmpty());
		assertTrue(DataManipulation.searchEntry(phonebook, "1", en.getlName()).isEmpty());
	}
	@Test //4
	void testFileInput() {
		assertFalse(FileOperations.fileInput().isEmpty());
	}
	@Test //5
	void testToString() {
		assertEquals(en.toString(), "\nVezet�kn�v: " + en.getfName() + "\nKeresztn�v: " + en.getlName() + "\nBecen�v: " + en.getnName() + "\nC�m: " + en.getAddress() + "\nMunkahelyi telefonsz�m: " + en.getwNum() + "\nPriv�t telefonsz�m: " + en.getpNum() + "\n===========================\n");
	}
	@Test //6
	void testToFile() {
		assertEquals(en.toFile(), en.getfName() + "_" + en.getlName() + "_" + en.getnName() + "_" + en.getAddress() + "_" + en.getwNum() + "_" + en.getpNum() + "\n");
	}
	@Test //7
	void testToVCF() {
		assertEquals(en.toVCF(), "BEGIN:VCARD\nVERSION:2.1\nN;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:" + Entry.stringToHexASCII(en.getfName()) + ";" + Entry.stringToHexASCII(en.getlName()) + ";;;\nFN;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:" + Entry.stringToHexASCII(en.getlName()) + "=20" + Entry.stringToHexASCII(en.getfName()) + "\nX-ANDROID-CUSTOM;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:vnd.android.cursor.item/nickname;" + Entry.stringToHexASCII(en.getnName()) + ";=31;;;;;;;;;;;;;\nTEL;WORK:" + en.getwNum() + "\nTEL;CELL:" + en.getpNum() + "\nADR;HOME;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:;;" + Entry.stringToHexASCII(en.getAddress()) + ";;;;\nEND:VCard\n\n");
	}
	@Test //8
	void testHexASCII() {
		assertTrue(Entry.stringToHexASCII("A").equals("=41"));
	}
	@Test //9
	void testIsInTheList() {
		phonebook.add(en3);
		assertFalse(DataManipulation.isInTheList(phonebook, en3.getwNum()).equals(null));
	}
	@Test //10
	void testFileOptput() {
		FileOperations.fileOutput(phonebook, true); ///assertThrows()
		assertFalse(FileOperations.fileInput().isEmpty());
	}
}