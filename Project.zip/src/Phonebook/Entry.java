package Phonebook;
public class Entry {
	private EntryName lastName;
	private EntryName firstName;
	private EntryName nickName;
	private EntryAddress address;
	private EntryPhone workNum;
	private EntryPhone privateNum;
	
	public Entry(String lastName, String firstName, String nickName, String address, String workNum, String privateNum) {
		this.lastName = new EntryName(lastName);
		this.firstName = new EntryName(firstName);
		this.nickName = new EntryName(nickName);
		this.address = new EntryAddress(address);
		this.workNum = new EntryPhone(workNum);
		this.privateNum = new EntryPhone(privateNum);
	}
	
	public String toString() { //used for printing to screen (console)
		return "\nVezet�kn�v: " + this.firstName + 
				"\nKeresztn�v: " + this.lastName + 
				"\nBecen�v: " + this.nickName + 
				"\nC�m: " + this.address + 
				"\nMunkahelyi telefonsz�m: " + this.workNum + 
				"\nPriv�t telefonsz�m: " + this.privateNum 
				+ "\n===========================\n"; }
	
	public String toFile() { //used to write to txt database file
			return this.firstName +
			"_" + this.lastName +
			"_" + this.nickName + 
			"_" + this.address + 
			"_" + this.workNum + 
			"_" + this.privateNum + "\n"; }
	
	public String toVCF() { //used to write .vcf files
		return "BEGIN:VCARD\nVERSION:2.1\n"
				+ "N;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:" + stringToHexASCII(this.firstName.getValue()) + ";" + stringToHexASCII(this.lastName.getValue()) + ";;;\n"
				+ "FN;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:" + stringToHexASCII(this.lastName.getValue()) + "=20" + stringToHexASCII(this.firstName.getValue())
				+"\nX-ANDROID-CUSTOM;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:vnd.android.cursor.item/nickname;" + stringToHexASCII(this.nickName.getValue()) + ";=31;;;;;;;;;;;;;"
				+ "\nTEL;WORK:" + this.workNum
				+ "\nTEL;CELL:" + this.privateNum
				+ "\nADR;HOME;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:;;" + stringToHexASCII(this.address.getValue()) + ";;;;"
				+ "\nEND:VCard\n\n";
	}
	/** 
	 * This method converts a String to a HEX ASCII character chain, separated with the symbol "="
	 * This is essential for the Hungarian encoding to VCF files
	 * This part of the code is slightly inspired by Mkyong.com (https://mkyong.com/java/how-to-convert-hex-to-ascii-in-java/)**/
	public static String stringToHexASCII(String s) {
		String ret="="; //starts with "="
		char[] array = s.toCharArray(); //converts the string to char array
		for (int i=0; i<array.length; i++) {
			int dec = (int) array[i]; //gets the char's ASCII code
			ret += Integer.toHexString(dec); //converts it to hex ASCII code
			if (array.length-1 != i) ret += "="; //if it is the last character, do not write an "=" after it
		}
		return ret;
	}
	
	// Getter methods
	public String getlName() { return this.lastName.getValue(); }
	public String getfName() { return this.firstName.getValue(); }
	public String getnName() { return this.nickName.getValue(); }
	public String getAddress() { return this.address.getValue(); }
	public String getwNum() { return this.workNum.getValue(); }
	public String getpNum() { return this.privateNum.getValue(); }	
}