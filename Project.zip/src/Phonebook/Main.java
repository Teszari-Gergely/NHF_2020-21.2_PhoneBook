package Phonebook;
import java.util.Scanner;
import java.io.IOException;
import java.util.ArrayList;
public class Main {
	private static Scanner input = new Scanner(System.in);
	/** 
	 * This method waits for a button to be pressed to continue the menu looping process**/
	public static void exit() {
		System.out.println("\n�ss�n entert a folytat�shoz...");
		try { System.in.read(); }
		catch (IOException e) { System.out.println("Hiba t�rt�nt!"); e.printStackTrace(); }
		cls();
	}
	/** 
	 * This method is a screen clearer
	 * Inspiration by some YouTube video I can't find anymore...**/
	public static void cls() {
		try {
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		} catch (IOException e) { System.out.println("Hiba t�rt�nt!"); e.printStackTrace(); }
		catch (InterruptedException e2) { System.out.println("Hiba t�rt�nt!"); e2.printStackTrace(); }
	}
	/** 
	 * This is the main method
	 * It is a looping menu, displayed again and again
	 * It asks in every parameters for methods, such as the mode of searching, the phone number asked to be removed, etc.**/
	public static void main(String[] args) {
		ArrayList<Entry> list0 = new ArrayList<Entry>();
		list0 = FileOperations.fileInput();
		while (true) {
			cls();
			System.out.println("�dv�zl�m a Jaser telefonk�nyv programban!\nMit k�v�n tenni?");
			if (list0.size() == 0) { System.out.print("\nAdatok bevitele:\tb\n>>>"); }
			else {
			System.out.print("\nAdatok bevitele:\t\tb"
					+ "\n\nAdatok t�rl�se:\t\t\tt"
					+ "\n\nAdatok list�z�sa:\t\tl"
					+ "\n\nKeres�s:\t\t\tk"
					+ "\n\nAdatok export�l�sa .VCF f�jlba:\tv"
					+ "\n\nMent�s:\t\t\t\tm"
					+ "\n\nMent�s �s kil�p�s:\t\tx\n\n>>>");
				}
			String Choose = input.next().trim();
			if (Choose.toLowerCase().equals("l")) { //l stands for "list�z�s", listing
				if (list0.isEmpty()) { System.out.println("M�g nincsenek bejegyz�sek!"); exit(); }
				else { cls(); for (Entry e: list0) { System.out.println(e); } exit(); } //Entry by Entry, not the ArrayList printed out
				}
			else if (Choose.toLowerCase().equals("b")) { //b stands for "bevitel", input
				cls(); DataManipulation.GUI(list0, "add"); exit(); }
			else if (Choose.toLowerCase().equals("t")) { //t stands for "t�rl�s", delete
					cls(); DataManipulation.GUI(list0, "del"); exit(); 
				}
			else if (Choose.toLowerCase().equals("k")) { //k stands for "keres�s", search
					cls(); DataManipulation.GUI(list0, "src"); exit(); 
				}
			else if (Choose.toLowerCase().equals("v")) { //v stands for VCF
				if (list0.isEmpty()) { System.out.println("M�g nincsenek bejegyz�sek!"); exit(); }
				else { cls(); FileOperations.fileOutput(list0, false); exit(); } //false means the output file format is VCF
				}
			else if (Choose.toLowerCase().equals("m")) { FileOperations.fileOutput(list0, true); exit(); } //m stands for "ment�s", save. True means the output file format is VCF
			else if (Choose.toLowerCase().equals("x")) { FileOperations.fileOutput(list0, true); exit(); break; } //x mimics the X in the right upper corner
			else { System.out.println("Ilyen opci� nincs!"); exit(); }
			}
		}
}