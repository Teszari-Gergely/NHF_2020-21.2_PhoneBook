package Phonebook;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
public class FileOperations {
	/** 
	 * This method is responsible for the file reading
	 * Breaks the file to lines, and split the lines between underscores
	 * Calls the stringToEntry method, to convert the split lines to entries
	 * These will be added to an ArrayList, that is the return of this method**/
	public static ArrayList<Entry> fileInput() {
		ArrayList<Entry> ret = new ArrayList<Entry>(); //the database
		try {
			BufferedReader reader = new BufferedReader(new FileReader("Entries.txt"));
			while (true) {
				String line = reader.readLine(); //reading the file line by line
				if (line == null) break; //end of the file
				String[] result = line.split("_"); //separator character: "_"
				ret.add(stringToEntry(result)); //giving the successfully red Entry to the database
			}
			reader.close();
		} catch (IOException e) {
			System.out.println("A f�jl hib�s vagy nem tal�lhat�!"); //invalidly stored data, or not existing file
		}
		return ret;
	}
	/** 
	 * This method converts a String[] array to an Entry**/
	public static Entry stringToEntry(String[] s) {
		return new Entry(s[0], s[1], s[2], s[3], s[4], s[5]);
	}
	/** 
	 * This method makes a .TXT file or a .VCF out of an entries filled ArrayList
	 * The separator character as a .TXT is an underscore, as given in the toFile() method
	 * As for .VCF, it gives the appropriate header, makers, etc to the entrie's parts
	 * This kind of .vcf file is readable mostly for Android devices and Windows**/
	public static void fileOutput(ArrayList<Entry> list, boolean TXTorVCF) {
		try {
			if (TXTorVCF) { //true, if the desired file format is TXT
				FileWriter writer = new FileWriter("Entries.txt");
				for (int i=0; i< list.size(); i++) {
					writer.write(list.get(i).toFile()); //specified writer syntactic
					}
				writer.close();
				System.out.println("F�jlba �r�s sikeres.");
				}
			else if (!TXTorVCF){ //false, if the desired file format is TXT
				FileWriter writer = new FileWriter("Entries.vcf");
		        for (int i=0; i< list.size(); i++) {
		        	writer.write(list.get(i).toVCF()); //specified writer syntactic
		        }
		        writer.close();
		        System.out.println("F�jlba �r�s sikeres.");	//successful writing
			}
	      } catch (IOException e) {
	        System.out.println("Hiba t�rt�nt a f�jlba �r�s sor�n!");
	        e.printStackTrace();
	      }
		}
}