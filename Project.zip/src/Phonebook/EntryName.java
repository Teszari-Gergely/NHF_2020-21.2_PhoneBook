package Phonebook;

public class EntryName extends EntryData{
	protected EntryName(String value) { super(value); }
}
