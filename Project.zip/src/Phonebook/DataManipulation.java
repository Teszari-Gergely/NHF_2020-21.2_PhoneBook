package Phonebook;
import java.util.ArrayList;
//import java.util.Collections;
import java.util.Scanner;
public class DataManipulation {
	public static Scanner input = new Scanner(System.in);
	/** 
	 * This method checks whether a searched phone number is in the ArrayList or not.
	 * Parameters are the ArrayList itself and the searched phone number, in String format 
	 * It searches through the work place phone numbers and private phone numbers of all entries**/
	public static Entry isInTheList(ArrayList<Entry> list, String searchedNumber) {
		for (Entry en : list) {
			if (en.getwNum().equals(searchedNumber) || en.getpNum().equals(searchedNumber)) {
				return en; //returns with the reference of the fount item
				}
			}
		return null; //if no result found
	}
	/** 
	 * This method is a helper for main()
	 * It provides the graphical interface to methods, that require it
	 * It makes the whole method calling process much cleaner, and easier to see trough*/
	public static void GUI(ArrayList<Entry> list, String met) {
		if ((met.equals("del") || met.equals("list") || met.equals("src") || met.equals("vcf")) && list.isEmpty()) System.out.println("M�g nincsenek bejegyz�sek!");
		else if (met.equals("add")) {
			input.useDelimiter("\n");
			System.out.print("Adja meg az �j rekord vezet�knev�t:\n>>>");
			String newLastName = input.next().trim(); //always remove the \n character
			System.out.print("\nAdja meg az �j rekord keresztnev�t:\n>>>");
			String newFirstName = input.next().trim();
			System.out.print("\nAdja meg az �j rekord becenev�t:\n>>>");
			String newNickName = input.next().trim();
			System.out.print("\nAdja meg az �j rekord lakc�m�t:\n>>>");
			String newAddress = input.next().trim();
			System.out.print("\nAdja meg az �j rekord munkahelyi telefonsz�m�t: \n>>>");
			String newWorkNumber = input.next().trim();
			System.out.print("\nAdja meg az �j rekord otthoni telefonsz�m�t: \n>>>");
			String newPrivateNumber = input.next().trim();
			addNew(list, new Entry(newLastName, newFirstName, newNickName, newAddress, newWorkNumber, newPrivateNumber));
		}
		else if (met.equals("del")) {
			for (Entry en: list) {
				System.out.println(en); //printing out all the entries
			}
			System.out.print("Adja meg a telefonsz�mot, amihez tartoz� kontaktot el k�v�nja t�vol�tani: \n>>>");
			String which = input.next().trim();
			removeEntry(list, which);
		}
		else if (met.equals("src")) {
			System.out.print("Hogyan k�v�n keresni?\nN�v alapj�n:\t\t1\nTelefonsz�m alapj�n:\t2\n>>>");
			String mode = input.next().trim(), data = ""; //1: search by name, 2: search by phone number
			if (mode.equals("1")) {
				System.out.print("A teljes nevet sz�k�zzel elv�lasztva k�rem!\n>>>");
			}
			else if (mode.equals("2")) {
				System.out.print("Adja meg a keresett telefonsz�mot:\n>>>");
			}
			else { System.out.println("Nincs ilyen opci�!"); return; }
			data = input.next().trim(); //searched data gets asked in anyway, if valid search method is given
			ArrayList<Entry> templist = searchEntry(list, mode, data); //storing the results in an ArrayList
			if (!templist.isEmpty()) { //if empty, we'll get an error message in the called method
				for (Entry en: templist) //else print out all the entries one by one
				System.out.println(en);
			}
		}
	}
	/** 
	 * This method is responsible for adding new entries to the ArrayList
	 * It checks with the isInTheList method whether the given new contact's any phone number existed before in the ArrayList
	 * If yes, it gives an error message
	 * If not, than adds the new entry to the ArrayList, gives a feedback to the user**/
	public static boolean addNew(ArrayList<Entry> list, Entry en) {
		if(isInTheList(list, en.getwNum())!=null || isInTheList(list, en.getpNum())!=null) { //if the given new contact's any phone number has been in the database earlier
			System.out.println("\nIlyen adat m�r szerepelt kor�bban!"); return false;
		} else { list.add(en); System.out.println("\nSikeres hozz�ad�s!"); return true; } //else give it to the database
		} //the return indicates if the new contact was or wasn't given to the list successfully
	/** 
	 * This method is responsible for removing entries by any phone number
	 * Firstly, it lists all the entries
	 * Then it checks whether the searched phone number exist in any contact's any phone number field (done by isInTheList method)
	 * If not, it prints an error message
	 * If the number is found anywhere, it removes it form the ArrayList by the return value of isInTheList(), printing out a feedback message to the user
	 * **/
	public static boolean removeEntry(ArrayList<Entry> list, String which){
		Entry res=isInTheList(list, which); //gets the searched Entry, if is exists
		if (res!=null) { //the searched Entry exists
			list.remove(res);
			System.out.println("Sikeres t�rl�s: " + which); //just to make sure, which phone number was removed
			return true;
			}
		System.out.println("Ilyen telefonsz�mmal nincs elem az adatb�zisban."); //the searched Entry does not exists
		return false;
	}
	/** 
	 * This method is a searcher engine
	 * It can search by name, or phone number**/
	public static ArrayList<Entry> searchEntry(ArrayList<Entry> list, String mode, String data) {
		ArrayList<Entry> ret = new ArrayList<Entry>(); //this ArrayList will contain the fount results
		if (mode.equals("1")) { // Search by (full) name
			String[] result = data.split(" ");
			for (Entry en: list) {
				String fullname = String.join(" ", en.getfName(), en.getlName(), en.getnName()); //the databases's all item's name is joined together one by one, to check if it contains any of the searched data
				for (String s: result) {
					if (fullname.contains(s)) { 
						ret.add(en); break; //do not add multiple times, if more than one data matches with the searched
						}
					}
				}
			if (ret.isEmpty()) System.out.println("Nem tal�lhat� a keresett adat!");
		}
		else if (mode.equals("2")) { // Search by phone number
			Entry res = isInTheList(list, data); //if there is an Entry with this phone number, it's reference will be stored here
			if (res==null) System.out.println("Nem tal�lhat� ilyen sz�mmal adat!"); 
			else { ret.add(res); }
			}
	return ret; //always return at least an empty list
	}
}