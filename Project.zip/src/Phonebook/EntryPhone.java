package Phonebook;

public class EntryPhone extends EntryData {
	protected EntryPhone(String value) { super(value); }
}
