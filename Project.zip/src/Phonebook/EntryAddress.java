package Phonebook;

public class EntryAddress extends EntryData{
	protected EntryAddress(String value) { super(value); }
}
