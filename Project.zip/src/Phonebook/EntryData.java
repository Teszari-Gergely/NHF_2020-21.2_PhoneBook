package Phonebook;

abstract public class EntryData {
	protected String value;
	protected EntryData(String value) { this.value=value; }
	public String toString() { return getValue(); }
	public String getValue() { return this.value; }
	public void setValue(String s) { this.value=s; }
}